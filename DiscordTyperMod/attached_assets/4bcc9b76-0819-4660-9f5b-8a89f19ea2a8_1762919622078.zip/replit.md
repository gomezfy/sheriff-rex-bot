# Sheriff Rex - Bot Discord TypeScript

## Visão Geral
**Sheriff Rex** é um bot Discord completo com tema de Velho Oeste, desenvolvido em TypeScript. Possui sistema robusto de economia, moderação, mini jogos e funcionalidades de IA.

**Status**: ✅ Build corrigido e pronto para deploy no VertraCloud
**Última atualização**: 12 de novembro de 2025

### ⚡ Correções Recentes (12/11/2025)
- ✅ **CORRIGIDO**: Problema de variáveis de ambiente no VertraCloud
  - Substituído `import "dotenv/config"` por carregamento condicional
  - Adicionado suporte para variáveis injetadas pelo sistema (VertraCloud/produção)
  - Mantida compatibilidade com arquivo .env local (Replit/desenvolvimento)
  - Adicionado debug para verificar variáveis sem expor valores sensíveis
  - **Bot agora funciona perfeitamente no VertraCloud**
  - Ver detalhes em: `VERTRACLOUD_FIX.md`

### ⚡ Correções Anteriores (11/11/2025)
- ✅ **CORRIGIDO**: Problema de build no VertraCloud
  - Convertidos todos os 32 comandos de CommonJS para ES Modules
  - Corrigidos exports duplicados e problemas de tipagem
  - Build TypeScript compila sem erros

---

## Informações do Projeto

### Tecnologias
- **Runtime**: Node.js v20.19.3
- **Linguagem**: TypeScript 5.9.3
- **Framework Principal**: Discord.js v14.24.2
- **Banco de Dados**: Neon PostgreSQL (via Drizzle ORM)
- **Canvas**: @napi-rs/canvas (para gráficos e imagens)

### Arquitetura
```
src/
├── commands/          # Comandos slash organizados por categoria
│   ├── admin/        # Comandos de moderação (warn, mute, clear)
│   ├── ai/           # Integração com IA (OpenRouter)
│   ├── bounty/       # Sistema de recompensas
│   ├── economy/      # Sistema econômico
│   ├── gambling/     # Mini jogos (dice, duel, bankrob, roulette)
│   ├── guild/        # Sistema de guildas
│   ├── mining/       # Sistema de mineração
│   └── profile/      # Perfis de usuário
├── events/           # Event handlers do Discord
├── utils/            # Utilitários e gerenciadores
├── types/            # Definições TypeScript
└── data/             # Dados persistentes (JSON)
```

---

## Comandos Disponíveis

### 🛡️ Moderação (12 comandos)
- `/warn` - Dar aviso a um membro com motivo
- `/warnings` - Ver avisos de um membro
- `/clearwarns` - Limpar avisos de um membro
- `/mute` - Silenciar membro temporariamente (1-40320 min)
- `/unmute` - Remover silenciamento
- `/clear` - Deletar mensagens em massa (1-100)
- `/setlogs` - Configurar canal de logs de moderação
- `/admin` - Painel de comandos administrativos
- `/embedbuilder` - Construtor de embeds personalizados
- `/welcome` - Configurar mensagem de boas-vindas
- `/addreward` - Adicionar recompensa por nível
- `/criaservidor` - Criar canais e cargos com IA

### 💰 Economia (14 comandos)
**Moedas**: Saloon Tokens (premium) + Silver Coins (padrão)

- `/daily` - Recompensa diária
- `/give` - Transferir moedas/itens para outro usuário
- `/leaderboard` - Top 10 jogadores mais ricos
- `/territories` - Comprar territórios para renda passiva
- `/expedition` - Expedições de 3h ou 10h para recursos
- `/middleman` - Sistema de troca segura
- `/redeem` - Resgatar códigos de recompensa

**Comandos Admin**:
- `/addgold`, `/addsilver`, `/addtokens` - Adicionar moedas
- `/removegold` - Remover ouro
- `/addbackpack` - Upgrade de mochila
- `/addseal` - Adicionar selos
- `/setuptoken` - Configurar sistema de tokens

### 🎰 Mini Jogos (5 comandos)
- `/dice` - Duelo de dados PvP com apostas (min: 10 tokens)
- `/bankrob` - Assalto ao banco cooperativo (2 jogadores)
- `/duel` - Duelo PvP estilo Velho Oeste
- `/roulette` - Roleta de cassino
- `/roubo` - Roubo de gado cooperativo (2-4 jogadores)

### ⛏️ Mineração (1 comando)
- `/mine` - Minerar ouro
  - **Solo**: 90 minutos
  - **Cooperativo**: 30 minutos (2+ jogadores)
  - Sistema de mochila: 100kg → 500kg
  - Boost de 50% para donos de Gold Mine Shares

### 🔫 Recompensas/Bounty (4 comandos)
- `/wanted` - Colocar recompensa em alguém
- `/bounties` - Ver recompensas ativas
- `/capture` - Capturar procurado e receber recompensa
- `/clearbounty` - Limpar recompensa (admin)

### 🤖 IA (2 comandos)
- `/ai` - Chat com Sheriff Rex AI
- `/models` - Listar modelos OpenRouter disponíveis

### 🏰 Guildas (1 comando)
- `/guilda` - Sistema de guildas para jogadores

### 📊 Perfil (1 comando)
- `/profile` - Ver perfil visual do jogador

**Total**: 46 comandos slash registrados

---

## Recursos Especiais

### Sistema de XP e Níveis
- Ganho de XP por mensagens (com throttle anti-spam)
- Sistema de recompensas por nível configurável
- Leaderboard visual

### Sistema de Backup Automático
- Backup automático a cada 14 horas
- Arquivos ZIP compactados
- Backup de todos os dados JSON

### Otimizações de Performance
- Cache otimizado para produção e low memory
- Garbage collection manual
- Memory sweepers agressivos
- Sharding support para múltiplos servidores

### Sistemas Automáticos
- 💰 Renda de territórios (ciclo de 23 horas)
- ⛏️ Notificações de mineração
- 🗺️ Verificador de expedições (a cada 1 minuto)
- 📊 Reset de estatísticas de armazém (a cada hora)
- 🔄 Rotação de status (a cada 60 segundos)

### Logs de Moderação
Eventos registrados automaticamente:
- Mensagens deletadas/editadas
- Membros entrando/saindo
- Bans/Unbans
- Avisos e silenciamentos
- Atualizações de cargos e canais

---

## Variáveis de Ambiente

### Obrigatórias ✅
```
DISCORD_TOKEN         # Token do bot Discord
DISCORD_CLIENT_ID     # ID da aplicação Discord
OWNER_ID             # ID do dono do bot
```

### Opcionais
```
# IA
OPENROUTER_API_KEY   # Para comandos de IA

# Pagamentos
STRIPE_SECRET_KEY    # Para sistema de tokens premium
HOTMART_CLIENT_ID    # Integração Hotmart

# Configurações
NODE_ENV             # production ou development
LOW_MEMORY           # true para modo low memory
SESSION_SECRET       # Secret para sessões (gerado automaticamente)
```

---

## Configuração Inicial

### 1. Credenciais Discord
As credenciais já estão configuradas como secrets no Replit:
- `DISCORD_TOKEN`
- `DISCORD_CLIENT_ID`
- `OWNER_ID`

### 2. Registrar Comandos
```bash
npm run deploy
```

### 3. Executar Bot
```bash
npm run start
```

---

## Scripts Disponíveis

### Desenvolvimento
```bash
npm run dev              # Modo desenvolvimento com ts-node
npm run dev:shard        # Desenvolvimento com sharding
```

### Produção
```bash
npm run start            # Produção normal (1800MB)
npm run start:shard      # Produção com sharding
npm run start:vertra     # Low memory mode (512MB)
npm run start:low-memory # Ultra low memory (64MB)
```

### Build e Deploy
```bash
npm run build            # Compilar TypeScript
npm run deploy           # Registrar comandos no Discord
npm run prod             # Build + Start
```

### Banco de Dados
```bash
npm run db:push          # Push schema Drizzle
npm run db:studio        # Drizzle Studio UI
npm run db:migrate       # Migrar para PostgreSQL
```

### Qualidade de Código
```bash
npm run lint             # Verificar erros
npm run lint:fix         # Corrigir erros automaticamente
npm run format           # Formatar código
npm run validate         # Format + Lint Fix
```

---

## Banco de Dados

### Sistema Atual
- **Armazenamento**: JSON files em `src/data/`
- **13 arquivos** criados automaticamente
- Backup automático integrado

### PostgreSQL (Disponível)
O projeto está preparado para migração para PostgreSQL usando:
- **Drizzle ORM**: ORM type-safe
- **Neon Database**: PostgreSQL serverless
- Scripts de migração: `npm run db:migrate`

---

## Estrutura de Dados

### Arquivos JSON
```
src/data/
├── users.json           # Dados de usuários (economia, XP)
├── guilds.json          # Configurações de servidores
├── warns.json           # Sistema de avisos
├── mutes.json           # Silenciamentos ativos
├── mod-logs.json        # Configuração de logs
├── bounties.json        # Recompensas ativas
├── territories.json     # Territórios comprados
├── expeditions.json     # Expedições em andamento
├── mining.json          # Sessões de mineração
├── warehouse.json       # Armazéns de prata
└── [outros arquivos]
```

---

## Próximos Passos Sugeridos

### Curto Prazo
1. ✅ Testar comandos de moderação (`/warn`, `/mute`, `/clear`)
2. ✅ Testar mini jogos (`/dice`, `/duel`, `/bankrob`)
3. ✅ Testar sistema de economia (`/daily`, `/give`, `/leaderboard`)
4. Configurar `/setlogs` para ver logs de moderação
5. Testar sistema de mineração `/mine`

### Médio Prazo
1. Configurar API do OpenRouter para comandos de IA
2. Migrar para PostgreSQL se necessário
3. Configurar Stripe para tokens premium
4. Adicionar mais mini jogos
5. Expandir sistema de guildas

### Longo Prazo
1. Sistema de achievements (conquistas)
2. Eventos automáticos programados
3. Sistema de clãs expandido
4. Dashboard web de gerenciamento
5. Sistema de ranking global

---

## Problemas Conhecidos

### ⚠️ Avisos (Não Críticos)
- **OpenRouter API**: IA não configurada (comandos `/ai` e `/models` não funcionarão até adicionar `OPENROUTER_API_KEY`)
- **4 vulnerabilidades moderadas** nas dependências npm (rodar `npm audit fix`)

### ✅ Funcionando Perfeitamente
- Sistema de comandos (46 comandos registrados, incluindo `/roubo` corrigido)
- Sistema de eventos
- Cache e otimizações
- Backup automático
- Sistemas automáticos (territórios, mineração, expedições)

---

## Comandos Úteis

### Verificar Status
```bash
# Ver logs do bot
npm run start

# Verificar saúde do sistema
npm run health
```

### Debug
```bash
# Modo desenvolvimento com logs detalhados
npm run dev

# Verificar compilação TypeScript
npm run build
```

### Manutenção
```bash
# Atualizar dependências
npm update

# Limpar e reinstalar
rm -rf node_modules package-lock.json && npm install
```

---

## Suporte e Recursos

- **Autor**: gomezfy
- **Repositório**: https://github.com/gomezfy/Sheriffbot-
- **Discord.js Docs**: https://discord.js.org/
- **TypeScript**: https://www.typescriptlang.org/

---

## Notas de Desenvolvimento

### Convenções de Código
- Usar TypeScript strict mode
- Seguir ESLint + Prettier
- Usar async/await para operações assíncronas
- Implementar tratamento de erros robusto

### Performance
- Bot otimizado para 1800MB de memória
- Suporte para low memory (512MB e 64MB)
- Cache agressivo para reduzir uso de API
- Sweepers automáticos

### Segurança
- Validação de variáveis de ambiente
- Sanitização de erros para logs
- Permissões específicas por comando
- Sistema de cooldowns anti-spam

---

**Status Atual**: ✅ Bot online e funcionando perfeitamente!
